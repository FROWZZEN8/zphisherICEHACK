<p align="left">
<a href="#"><img title="Made in India" src="https://img.shields.io/badge/MADE%20IN-INDIA-green?colorA=#FF9933&colorB=#138808&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Xphisher" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/banner/xphisher.png"></a>
</p>
<p align="center">
<a href="https://github.com/deco-der"><img title="Author" src="https://img.shields.io/badge/Author-htr--tech-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-2.0-green.svg?style=flat-square"></a>
<a href="#"><img title="Language" src="https://badges.frapsoft.com/bash/v1/bash.png?v=103"></a>
<a href="https://github.com/htr-tech/followers"><img title="Followers" src="https://img.shields.io/github/followers/htr-tech?color=blue&style=flat-square"></a>
<a href="https://github.com/htr-tech/zphisher/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/htr-tech/zphisher?color=red&style=flat-square"></a>
<a href="https://github.com/htr-tech/zphisher/network/members"><img title="Forks" src="https://img.shields.io/github/forks/htr-tech/zphisher?color=red&style=flat-square"></a>
<a href="https://github.com/htr-tech/zphisher/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/htr-tech/zphisher?label=Watchers&color=blue&style=flat-square"></a>
</p>

## Installation :

* `apt update`
* `apt install git curl php openssh -y`
* `git clone https://github.com/RAJESHMUDI/xphisher.git`
* `cd zphisher`
#### > Run : `bash zphisher.sh`

## Single Command :
```
apt update ; apt install git curl php openssh -y ; git clone git://github.com/htr-tech/zphisher.git ; cd zphisher ; bash zphisher.sh
```
<br>
<p align="center">
<img width="40%" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/zphisher1.png"/>
<img width="51%" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/zphisher2.png"/>
</p>

### <<< If you copy , Then Give me The Credits >>>

## Features :
#### [+] Latest Login Pages !
#### [+] New Instagram Auto Follower Page !
#### [+] 4 Port Forwarding Options !
#### [+] Easy for Beginners !

## Credits :
#### > TheLinuxChoice (https://github.com/thelinuxchoice)
#### > DarksecDevelopers (https://github.com/DarksecDevelopers)
#### > UndeadSec (https://github.com/UndeadSec)

## Tunelling Options :
#### > Localhost (127.0.0.1)
#### > NGROK (https://ngrok.com)
#### > SERVEO (https://serveo.net)
#### > LOCALHOSTRUN (https://localhost.run)

## Find Me on :
[![Github](https://img.shields.io/badge/Github-HTR--TECH-green?style=for-the-badge&logo=github)](https://github.com/htr-tech)

